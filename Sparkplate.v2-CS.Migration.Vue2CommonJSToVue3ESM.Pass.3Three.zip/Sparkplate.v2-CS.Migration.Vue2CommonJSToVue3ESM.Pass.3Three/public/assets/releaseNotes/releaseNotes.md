July 2023 (version 1.0.0)

#### v1.0.0

A stripped down open source version of [Greenery](https://www.greenery.finance/) to be used as a base for various projects.
