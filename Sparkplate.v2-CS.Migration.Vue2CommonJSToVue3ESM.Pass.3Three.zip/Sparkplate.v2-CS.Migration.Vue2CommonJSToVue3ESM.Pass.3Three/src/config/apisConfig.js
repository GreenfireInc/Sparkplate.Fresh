export const BLOCK_CYPHER_API = 'https://api.blockcypher.com/v1'
export const blockchairCryptos = new Set(['btc', 'doge', 'ltc'])
export default {
  BLOCK_CYPHER_API,
  blockchairCryptos
}
