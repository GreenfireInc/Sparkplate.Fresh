export default {
  name: 'Sparkplate.vue',
  longName: 'Sparkplate.vue by Greenfire',
  siteUrl: 'https://greenfire.io/',
  iconUrl:
    'http://www.greenfire.io/wp-content/uploads/2022/06/green_16-220x300.png'
}
