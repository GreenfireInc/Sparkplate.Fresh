<template>
  <div>
    <h3 class="text-xl text-center">Thank you for choosing Sparkplate</h3>
  </div>
</template>
<script>
export default {
  name: 'WelcomeText'
}
</script>
