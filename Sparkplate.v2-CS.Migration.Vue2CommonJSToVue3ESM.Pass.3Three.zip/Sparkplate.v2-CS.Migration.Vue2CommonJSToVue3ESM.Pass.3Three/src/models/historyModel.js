class HistoryModel {
  constructor(currency, quantity, type, time) {
    this.currency = currency
    this.quantity = quantity
    this.type = type
    this.time = time
  }
}

export default HistoryModel
